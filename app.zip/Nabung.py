import streamlit as st

st.title("Ini Halaman nabung!")

with st.form("Nabung"):
    nama = st.text_input("Masukkan nama")
    nominal = st.number_input("Masukkan nominal nabung")
    submitButoon = st.form_submit_button("Simpan")

    if submitButoon:
        st.write(nama)
        st.session_state['Nabung'].append({
            "Nama" : nama,
            "Nominal" : nominal,
        })
        st.success("Berhasil menabung!")